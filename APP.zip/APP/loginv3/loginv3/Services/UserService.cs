﻿namespace loginv3.Services
{
    using loginv3.Models;
    using MongoDB.Driver;
    using System.Threading.Tasks;

    public class UserService : IUserService
    {
        private readonly IMongoCollection<User> _users;

        public UserService(IMongoClient client)
        {
            var database = client.GetDatabase("local");
            _users = database.GetCollection<User>("usuarios");
        }

        public async Task<User> RegisterAsync(User user)
        {
            await _users.InsertOneAsync(user);
            return user;
        }

        public async Task<User> LoginAsync(string email, string password)
        {
            return await _users.Find(u => u.Email == email && u.Password == password).FirstOrDefaultAsync();
        }
    }

}
