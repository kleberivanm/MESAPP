﻿using loginv3.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace loginv3.Services
{
    public interface IReservationService
    {
        Task<List<Reservation>> GetAllReservationsAsync(); // Método para obtener todas las reservas
    }
}
