﻿using MongoDB.Driver;
using loginv3.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace loginv3.Services
{
    public class ReservationService : IReservationService
    {
        private readonly IMongoCollection<Reservation> _reservations;

        public ReservationService(IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase("local");
            _reservations = database.GetCollection<Reservation>("reservas");
        }

        public async Task<List<Reservation>> GetAllReservationsAsync()
        {
            return await _reservations.Find(_ => true).ToListAsync(); // Devuelve todas las reservas
        }
    }
}
