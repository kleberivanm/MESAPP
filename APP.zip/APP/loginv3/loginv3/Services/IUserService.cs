﻿namespace loginv3.Services
{
    using loginv3.Models;
    using System.Threading.Tasks;

    public interface IUserService
    {
        Task<User> RegisterAsync(User user);
        Task<User> LoginAsync(string email, string password);
    }

}
