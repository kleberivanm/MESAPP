﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace loginv3.Models
{
    public class User
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } // MongoDB generará automáticamente un ObjectId si está vacío

        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
    public class Reservation
    {
        [BsonId] // Esto indica que este es el campo _id en MongoDB
        public ObjectId Id { get; set; }

        public string Restaurant { get; set; }
        public int PeopleCount { get; set; }
        public DateTime ReservationTime { get; set; }
    }

}
